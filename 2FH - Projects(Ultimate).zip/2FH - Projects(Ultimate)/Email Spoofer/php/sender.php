<?php

    function is_valid_email($str)

        {

            $result = (false !== filter_var($str, FILTER_VALIDATE_EMAIL));

            if ($result)

                {

                    list($user, $domain) = explode('@', $str);

                    $result = checkdnsrr($domain, 'MX');

                }

            return $result;

        }

    $from_name = $_POST['fname'];
    $from_email = $_POST['femail'];
    $to_email = $_POST['temail'];
    $subject = $_POST['sbjemail'];
    $content_type = ($_POST['ctype'] == 0) ? 'text/plain' : 'text/html';
    $message = $_POST['msg'];

    if (!is_valid_email($from_email) || !is_valid_email($to_email))

        {

            $answer = 0;
            
            echo $answer;
            
            exit();

        }

    else

        {

            $header = 'From: ' . $from_name . '<' . $from_email . '>' . "\r\n";
            $header .= "MIME-Version: 1.0" . "\r\n";
            $header .= 'Content-type: ' . $content_type . '; charset = UTF-8' . "\r\n";

            $answer = (mail($to_email, $subject, $message, $header)) ? 1 : 0;

            echo $answer;
            
            exit();

        }

?>
