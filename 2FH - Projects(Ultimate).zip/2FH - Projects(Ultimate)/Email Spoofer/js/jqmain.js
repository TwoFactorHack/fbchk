$(document).ready(function()

    {

        particlesJS("particles-js", null);

        var c1 = $('#fname');
        var c2 = $('#femail');
        var c3 = $('#temail');
        var c4 = $('#sbjemail');
        var c6 = $('#msg');

        var txt = $('#txt');
        var htm = $('#html');

        var lbltxt = $('#labelxslct1');
        var lblhtm = $('#labelxslct2');

        var see = 0;

        var send = $('#send');

        //alert($(window).width());

        if ($(window).width() < 400)

            {
  
                 
                 c6.css("width", ($(window).width() - 14) + "px");
                 c6.css("position", "absolute");
                 c6.css("left", "12.3%");
                 //alert("yes");

             }
             
             
             else if ($(window).width() >= 400 && $(window).width() < 442)
             
             
             {

                c6.css("width", ($(window).width() - 14) + "px");
                c6.css("position", "absolute");
                c6.css("left", "11px");
                //alert("yes");



             }


        function reset()
        
            {

                c1.val("");
                c2.val("");
                c3.val("");
                c4.val("");
                c6.val("");
                
                $("input").css("box-shadow", "0 0 10px white");
                c6.css("box-shadow", "0 0 10px white");
                txt.css("box-shadow", "0 0 10px white");
                htm.css("box-shadow", "0 0 10px white");
                send.css("box-shadow", "0 0 10px white");
                
                lbltxt.css("color", "white");
                lblhtm.css("color", "white");
                send.css("color", "white");
                
                send.prop("disabled", true);

                see = 0;

            }

        reset();

        function verifier()
        
            {

                function notEmpty(e)
                
                    {

                        ans = (e.val().trim() === "") ? false : true; 

                        return ans;

                    }

                if (notEmpty(c1) && notEmpty(c2) && notEmpty(c3) && notEmpty(c4) && notEmpty(c6) && (txt.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px" || htm.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px"))
                
                    {

                        send.prop("disabled", false);
                        send.css("color", "#58D3F7")
                        send.css("box-shadow", "0 0 10px #58D3F7");

                    }

                else
                
                    {

                        send.prop("disabled", true);
                        send.css("color", "white")
                        send.css("box-shadow", "0 0 10px white");

                    }

            }

        $("input").focus(function(e)
        
            {

                $(this).css("box-shadow", "0 0 10px #58D3F7");

            });

    
        $("textarea").focus(function(e)
    
            {

                $(this).css("box-shadow", "0 0 10px #58D3F7");

            });

        $("input").blur(function(e)
    
            {

                if ($(this).val().trim() === "")
            
                    {

                        $(this).css("box-shadow", "0 0 10px white");

                    }

            });

        $("textarea").blur(function(e)
    
            {

                if ($(this).val().trim() === "")
            
                    {

                        $(this).css("box-shadow", "0 0 10px white");

                    }

            });

        $("input").keyup(function(e)
        
            {

                verifier();

            });

        $("textarea").keyup(function(e)
        
            {

                verifier();

            });

        txt.click(function(e)

            {

                see = (htm.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px") ? (htm.css("box-shadow", "0 0 10px white"), lblhtm.css("color", "white"), 0) : see;

                if (see != 0)

                    {

                        txt.css("box-shadow", "0 0 10px white");
                        lbltxt.css("color", "white");

                        see = 0;

                    }

                else

                    {

                        txt.css("box-shadow", "0 0 10px #58D3F7");
                        lbltxt.css("color", "#58D3F7");

                        see += 1;

                    }

                verifier();

            });

        htm.click(function(e)

            {

                see = (txt.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px") ? (txt.css("box-shadow", "0 0 10px white"), lbltxt.css("color", "white"), 0) : see;

                if (see != 0)

                    {

                        htm.css("box-shadow", "0 0 10px white");
                        lblhtm.css("color", "white");
                        
                        see = 0;

                    }

                else

                    {

                        htm.css("box-shadow", "0 0 10px #58D3F7");
                        lblhtm.css("color", "#58D3F7");

                        see += 1;

                    }

                verifier();

            });

        send.click(function(e)

            {

                e.preventDefault();

                var c5 = (txt.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px") ? 0 : (htm.css("box-shadow") == "rgb(88, 211, 247) 0px 0px 10px 0px") ? 1 : alert("¡El tipo de contenido no ha sido seleccionado!");

                if (c5 == undefined)

                    {

                        return false;

                    }

                var formData = 'fname=' + c1.val() + '&femail=' + c2.val() + '&temail=' + c3.val() + '&sbjemail=' + c4.val() + '&ctype=' + c5 + '&msg=' + c6.val();

                // alert(formData);

                $.ajax(

                    {

                        type : "POST",
                        url : "/php/sender.php",
                        data : formData,

                        success : function(answer)

                            {
                                

                                if (answer == 1)

                                    {


                                        reset();
                                        alert("¡Email suplantado correctamente :)!");

                                    }

                                else if (answer == 0)

                                    {

                                        alert("¡Ha ocurrido un error durante el envío del Email :(!\n\nVerifica que los datos enviados sean correctos.");

                                    }
                                    
                                else
                                
                                    {
                                        
                                        alert("¡ERROR INTERNO, EN CASO DE QUE PERSISTA, PÓNGASE EN CONTACTO CON EL DESARROLLADOR DE LA PÁGINA!\n\n" + answer);
                                        
                                    }

                            },

                        error : function(xhr, ajaxOptions, thrownError)

                            {

                                alert("¡ERROR INTERNO, EN CASO DE QUE PERSISTA, PÓNGASE EN CONTACTO CON EL DESARROLLADOR DE LA PÁGINA!\n\nDescripción: " + thrownError + "\nCódigo de error: " + xhr.status);

                            }

                    });

            });

    });