<?php

    echo "¿Buscabas algo, perkin bastardo bueno pal kbza e' frutilla?";

?>