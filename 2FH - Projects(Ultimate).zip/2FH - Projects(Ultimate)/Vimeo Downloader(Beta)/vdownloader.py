################################################
# 2FH - Project -> Vimeo Downloader v1.0(BETA) #
# Autor -> def Empty():                        #
# Grupo -> TwoFactorHack - Unknowns            #
# Fecha: 1 de Junio del 2020                   #
# Hora: 1:00 AM                                #
################################################

import subprocess as sp
import json

def getPage():

    while (True):

        sp.run('clear', shell = True);

        url = input("\nVimeo downloader v1.0(BETA) by def Empty(): - 2FH\n\nIngrese la url de la web de la que desea descargar los videos(Vimeo)\nEjemplo: http://pentest.dsteamseguridad.com/hackstarted\n\n-> ");
        chk_url = sp.run('wget "' + url + '" -q -O index.html', shell = True);

        if (chk_url.returncode == 0):

            break;

        elif (chk_url.returncode == 5):

            input("\nVerifique que el protocolo de transferencia de la url sea correcto\n\nPresione intro para continuar...");

        else:

            input("\nNo se ha pudo resolver la dirección dada...\nVerifique que la url sea correcta o verifique su conexión a internet.\n\nPresione intro para continuar...");

    sp.run('clear', shell = True);

    print("\nObteniendo página web...");
    
    chk_url = sp.run('wget "' + url + '" -q -O index.html', shell = True, capture_output = True);

def getTitle():

    print("Extrayendo información de la página...");

    title = sp.check_output('cat index.html | grep "title"', shell = True);
    title = title.decode();
    title = title.replace("    ", "");
    title = title.split("\n");

    for t in title:

        if (t[1 : 6] == "title"):

            dirn = t.replace("<title>", "");
            dirn = dirn.replace("</title>", "");

            break;

    return dirn;

def getVimeoUrl():


    print("Extrayendo urls de vimeo...");

    iframe =  sp.run('cat index.html | grep \'<iframe width="1280" height="720"\'', shell = True, capture_output = True);

    if (iframe.returncode == 1):

        input("\n¡No se han encontrados urls de vimeo, verifique su url!\nPresione intro para salir...");
        exit();

    iframe = iframe.stdout.decode();
    iframe = iframe.split(" ");

    urls = [];

    for src in iframe:

        if (src[0:3] == "src"):

            url = src.split("\"");
            urls.append(url[1]);

    return urls;

def getVimeoJson(url_vimeo):

    print("Extrayendo código fuente de las urls de vimeo...");

    jsonf = [];

    for url in url_vimeo:

        sp.check_output('wget "' + url + '" -q -O index2.html', shell = True);

        html = sp.check_output('cat index2.html', shell = True);
        html = html.decode();
        html = html.split("; if (!config.request)");

        json_filter = html[0].split("var config = ");
        json_filter = json_filter[1];

        jsonf.append(json.loads(json_filter));

    return jsonf;

def getVideoInf(json_file):

    print("Extrayendo información de los videos encontrados...");

    inf = [];
    counter = 0;

    for url in json_file:

        title = str(json_file[counter]["video"]["title"]); 
        url_n = 0;

        for quality in json_file[counter]["request"]["files"]["progressive"]:

            if (str(quality["quality"]) != "720p"):

                url_n += 1;

            else:

                url = str(json_file[counter]["request"]["files"]["progressive"][url_n]["url"]);
                quality = str(json_file[counter]["request"]["files"]["progressive"][url_n]["quality"]);
                inf.append([title, url, quality]);
                url_n = 0;
                counter += 1;

    return inf;

def getVideo(dirn, inf):

    print("\nDescargando " + str(len(inf)) + " videos de\n\n" + dirn);
    sp.run("sleep 2s", shell = True);
    print("\nProgreso de la descarga\n");

    counter = 0;

    for dwnld in inf:

        sp.run('mkdir \'' + dirn + '\'', shell = True, capture_output = True);
        sp.run('cd \'' + dirn + '\' && wget -c "' + str(dwnld[1]) + '" -O "' + str(counter) + ' - ' + str(dwnld[0]) + '(' + str(dwnld[2]) + ').mp4" -q --show-progress', shell = True);

        counter += 1;

    print("\nLos videos han sido guardados en la carpeta:\n\n" + dirn);
    sp.run("rm index*", shell = True);

getPage();
dir_name = getTitle();
url_vimeo = getVimeoUrl();
vid_n = str(len(url_vimeo));
json_file = getVimeoJson(url_vimeo);
vid_inf = getVideoInf(json_file);

print("\n¡Proceso exitoso!");

sp.run("sleep 3s", shell = True);
sp.run("clear", shell = True);

print("\nTítulo\n\n" + dir_name);
print("\n# de videos encontrados -> " + vid_n);
sp.run('sleep 1s', shell = True);

print("Calidad de los videos -> " + str(vid_inf[0][2]));
sp.run('sleep 1s', shell = True)

input("\nPresione intro para iniciar la descarga...")

sp.run("clear", shell = True);

getVideo(dir_name, vid_inf);

input("\n¡Gracias por utilizar Vimeo Downloader by def Empty():!\nPresiona intro para salir...\n")